mkdir src
touch src/trash
touch src/main.c

echo "src/trash" >> .myideignore